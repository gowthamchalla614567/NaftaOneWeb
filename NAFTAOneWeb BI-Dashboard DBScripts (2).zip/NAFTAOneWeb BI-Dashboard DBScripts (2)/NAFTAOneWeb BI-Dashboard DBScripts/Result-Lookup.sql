-- Schema naftaonewebautomation
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `naftaonewebautomation` DEFAULT CHARACTER SET utf8 ;
USE `naftaonewebautomation` ;

-- -----------------------------------------------------
-- Table `naftaonewebautomation`.`result`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `naftaonewebautomation`.`result` (
 `ResultCode` int not null, 
 `Result` varchar(50) DEFAULT NULL,
 PRIMARY KEY(`ResultCode`));

INSERT INTO `naftaonewebautomation`.`result`
(
`ResultCode` ,
 `Result` 
 )
 Values
 (1, 'Pass'),
 (2, 'Fail')