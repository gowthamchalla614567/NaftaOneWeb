-- Schema naftaonewebautomation
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `naftaonewebautomation` DEFAULT CHARACTER SET utf8 ;
USE `naftaonewebautomation` ;

 -- -----------------------------------------------------
-- Table `naftaonewebautomation`.`region`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `naftaonewebautomation`.`region` (
 `RegionCode` int not null, 
 `Region` varchar(50) DEFAULT NULL,
 PRIMARY KEY(`RegionCode`));

INSERT INTO `naftaonewebautomation`.`region`
(
`RegionCode` ,
 `Region` 
 )
 Values
 (1, 'US'),
 (2, 'CA'),
 (3, 'MX')