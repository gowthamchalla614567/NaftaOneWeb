-- Schema naftaonewebautomation
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `naftaonewebautomation` DEFAULT CHARACTER SET utf8 ;
USE `naftaonewebautomation` ; 
 

-- -----------------------------------------------------
-- Table `naftaonewebautomation`.`language`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `naftaonewebautomation`.`language` (
 `LanguageCode` int not null, 
 `Language` varchar(50) DEFAULT NULL,
 PRIMARY KEY(`LanguageCode`));

INSERT INTO `naftaonewebautomation`.`language`
(
`LanguageCode` ,
 `Language` 
 )
 Values
 (1, 'EN'),
 (2, 'FR'),
 (3, 'SP')