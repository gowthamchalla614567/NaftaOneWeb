-- Schema naftaonewebautomation
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `naftaonewebautomation` DEFAULT CHARACTER SET utf8 ;
USE `naftaonewebautomation` ; 
 
-- -----------------------------------------------------
-- Table `naftaonewebautomation`.`modelyear`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `naftaonewebautomation`.`modelyear` (
 `ModelYearCode` int not null, 
 `ModelYear` varchar(50) DEFAULT NULL,
 PRIMARY KEY(`ModelYearCode`));

INSERT INTO `naftaonewebautomation`.`modelyear`
(
`ModelYearCode` ,
`ModelYear` 
 )
 Values
 (2020, 'MY20'),
 (2021, 'MY21')