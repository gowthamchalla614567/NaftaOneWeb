-- Schema naftaonewebautomation
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `naftaonewebautomation` DEFAULT CHARACTER SET utf8 ;
USE `naftaonewebautomation` ; 
 
-- -----------------------------------------------------
-- Table `naftaonewebautomation`.`type`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `naftaonewebautomation`.`type` (
 `TypeCode` int not null, 
 `Type` varchar(50) DEFAULT NULL,
 PRIMARY KEY(`TypeCode`));

INSERT INTO `naftaonewebautomation`.`type`
(
`TypeCode` ,
 `Type` 
 )
 Values
 (1, 'MYCO'),
 (2, 'NON MYCO'),
 (3, 'Global Nav'),
 (4, 'Special Offers')